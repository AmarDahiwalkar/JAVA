package CustomExceptionMess;

@SuppressWarnings("serial")
public class CustomExceptionMess extends Exception {
	public CustomExceptionMess(String msg) {
		super(msg);
	}
}
